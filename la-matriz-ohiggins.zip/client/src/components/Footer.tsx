/* ============================================================
   Footer — Cyberpunk Académico
   ============================================================ */
import { Link } from "wouter";
import { Zap, BookOpen, Compass } from "lucide-react";

export default function Footer() {
  return (
    <footer
      className="mt-24 border-t"
      style={{
        background: "rgba(5, 9, 20, 0.95)",
        borderColor: "rgba(0, 245, 212, 0.1)",
      }}
    >
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div
                className="w-8 h-8 rounded flex items-center justify-center"
                style={{ background: "rgba(0, 245, 212, 0.1)", border: "1px solid rgba(0, 245, 212, 0.3)" }}
              >
                <Zap size={16} style={{ color: "#00f5d4" }} />
              </div>
              <span className="font-bold text-lg" style={{ color: "#00f5d4", fontFamily: "'Space Grotesk', sans-serif" }}>
                La Matriz
              </span>
            </div>
            <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.45)" }}>
              Portal académico del Liceo Emblemático Libertador General Bernardo O'Higgins Riquelme.
            </p>
            <p className="text-sm mt-3" style={{ color: "rgba(0, 245, 212, 0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
              Prof. Camila Tapia Cisternas
            </p>
          </div>

          {/* Materias */}
          <div>
            <h4 className="text-sm font-semibold mb-4 uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.4)" }}>
              Materias
            </h4>
            <div className="flex flex-col gap-2">
              <Link href="/fisica">
                <span className="flex items-center gap-2 text-sm transition-colors duration-200 hover:text-white"
                  style={{ color: "rgba(255,255,255,0.55)" }}>
                  <BookOpen size={14} style={{ color: "#00f5d4" }} /> Física
                </span>
              </Link>
              <Link href="/orientacion">
                <span className="flex items-center gap-2 text-sm transition-colors duration-200 hover:text-white"
                  style={{ color: "rgba(255,255,255,0.55)" }}>
                  <Compass size={14} style={{ color: "#f72585" }} /> Orientación
                </span>
              </Link>
            </div>
          </div>

          {/* Info */}
          <div>
            <h4 className="text-sm font-semibold mb-4 uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.4)" }}>
              Establecimiento
            </h4>
            <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.45)" }}>
              Liceo Emblemático Libertador General Bernardo O'Higgins Riquelme
            </p>
          </div>
        </div>

        <div
          className="mt-10 pt-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs"
          style={{ borderTop: "1px solid rgba(0, 245, 212, 0.08)", color: "rgba(255,255,255,0.25)" }}
        >
          <span>© 2025 La Matriz · Liceo O'Higgins. Todos los derechos reservados.</span>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", color: "rgba(0, 245, 212, 0.3)" }}>
            v1.0.0
          </span>
        </div>
      </div>
    </footer>
  );
}
