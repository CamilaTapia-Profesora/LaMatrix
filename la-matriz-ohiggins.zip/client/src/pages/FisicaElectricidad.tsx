/* ============================================================
   Electricidad — Circuitos Interactivos
   ============================================================ */
import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Zap } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { CircuitVisualizer } from "@/components/CircuitVisualizer";

export default function FisicaElectricidad() {
  const [voltage, setVoltage] = useState(12);
  const [resistance, setResistance] = useState(4);
  const [isActive, setIsActive] = useState(false);

  return (
    <div className="min-h-screen" style={{ background: "#050914" }}>
      <NavBar />

      <section className="py-16">
        <div className="container">
          <Link href="/fisica">
            <span className="inline-flex items-center gap-1.5 text-sm mb-6 transition-colors hover:opacity-80"
              style={{ color: "rgba(0, 245, 212, 0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
              <ArrowLeft size={14} /> volver a física
            </span>
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(247, 37, 133, 0.1)", border: "1px solid rgba(247, 37, 133, 0.3)" }}>
              <Zap size={24} style={{ color: "#f72585" }} />
            </div>
            <div>
              <p className="text-xs font-medium" style={{ color: "rgba(247, 37, 133, 0.5)", fontFamily: "'JetBrains Mono', monospace" }}>
                // electricidad
              </p>
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Circuitos Eléctricos
              </h1>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Visualizador */}
            <div className="lg:col-span-2">
              <div className="cyber-card rounded-xl p-6 mb-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Circuito Simple: Fuente + Resistencia
                </h3>
                <CircuitVisualizer
                  voltage={voltage}
                  resistance={resistance}
                  isActive={isActive}
                />
              </div>

              <div className="cyber-card rounded-xl p-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Ley de Ohm
                </h3>
                <p className="text-sm mb-4" style={{ color: "rgba(255,255,255,0.7)", fontFamily: "'JetBrains Mono', monospace" }}>
                  V = I · R
                </p>
                <p className="text-xs mb-4" style={{ color: "rgba(255,255,255,0.5)" }}>
                  Donde: V es voltaje (V), I es corriente (A), R es resistencia (Ω)
                </p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>
                  Potencia: P = V · I = I² · R
                </p>
              </div>
            </div>

            {/* Controles */}
            <div className="lg:col-span-1">
              <div className="cyber-card rounded-xl p-6 sticky top-20">
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Parámetros
                </h3>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Voltaje: {voltage.toFixed(1)} V
                  </label>
                  <Slider
                    value={[voltage]}
                    onValueChange={(v) => setVoltage(v[0])}
                    min={0}
                    max={24}
                    step={0.5}
                    className="w-full"
                  />
                </div>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Resistencia: {resistance.toFixed(1)} Ω
                  </label>
                  <Slider
                    value={[resistance]}
                    onValueChange={(r) => setResistance(r[0])}
                    min={0.1}
                    max={20}
                    step={0.1}
                    className="w-full"
                  />
                </div>

                <button
                  onClick={() => setIsActive(!isActive)}
                  className="w-full py-3 rounded-lg font-semibold text-sm transition-all"
                  style={{
                    background: isActive ? "rgba(247, 37, 133, 0.15)" : "rgba(0, 245, 212, 0.15)",
                    border: `1px solid ${isActive ? "rgba(247, 37, 133, 0.4)" : "rgba(0, 245, 212, 0.4)"}`,
                    color: isActive ? "#f72585" : "#00f5d4",
                    fontFamily: "'Space Grotesk', sans-serif",
                  }}
                >
                  {isActive ? "Apagar" : "Encender"}
                </button>

                <div className="mt-6 p-4 rounded-lg" style={{ background: "rgba(0, 245, 212, 0.05)", border: "1px solid rgba(0, 245, 212, 0.1)" }}>
                  <p className="text-xs font-medium text-white mb-2">Cálculos:</p>
                  <div className="text-xs space-y-1" style={{ color: "rgba(255,255,255,0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
                    <p>I = {(voltage / (resistance || 1)).toFixed(2)} A</p>
                    <p>P = {(voltage * (voltage / (resistance || 1))).toFixed(1)} W</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
