/* ============================================================
   Magnetismo — Campos Magnéticos Interactivos
   ============================================================ */
import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Magnet } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { MagneticFieldVisualizer } from "@/components/MagneticFieldVisualizer";

export default function FisicaMagnetismo() {
  const [magnetStrength, setMagnetStrength] = useState(1);
  const [fieldType, setFieldType] = useState<"dipole" | "solenoid">("dipole");

  return (
    <div className="min-h-screen" style={{ background: "#050914" }}>
      <NavBar />

      <section className="py-16">
        <div className="container">
          <Link href="/fisica">
            <span className="inline-flex items-center gap-1.5 text-sm mb-6 transition-colors hover:opacity-80"
              style={{ color: "rgba(0, 245, 212, 0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
              <ArrowLeft size={14} /> volver a física
            </span>
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(114, 9, 183, 0.1)", border: "1px solid rgba(114, 9, 183, 0.3)" }}>
              <Magnet size={24} style={{ color: "#7209b7" }} />
            </div>
            <div>
              <p className="text-xs font-medium" style={{ color: "rgba(114, 9, 183, 0.5)", fontFamily: "'JetBrains Mono', monospace" }}>
                // magnetismo
              </p>
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Campos Magnéticos
              </h1>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Visualizador */}
            <div className="lg:col-span-2">
              <div className="cyber-card rounded-xl p-6 mb-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Visualización de Campos Magnéticos
                </h3>
                <MagneticFieldVisualizer
                  magnetStrength={magnetStrength}
                  fieldType={fieldType}
                />
              </div>

              <div className="cyber-card rounded-xl p-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Conceptos Fundamentales
                </h3>
                <div className="space-y-3 text-sm" style={{ color: "rgba(255,255,255,0.6)" }}>
                  <p><strong>Campo Magnético (B):</strong> Región del espacio donde se ejerce fuerza magnética.</p>
                  <p><strong>Líneas de Fuerza:</strong> Representan la dirección y magnitud del campo.</p>
                  <p><strong>Polos Magnéticos:</strong> Norte (N) y Sur (S) son inseparables.</p>
                </div>
              </div>
            </div>

            {/* Controles */}
            <div className="lg:col-span-1">
              <div className="cyber-card rounded-xl p-6 sticky top-20">
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Parámetros
                </h3>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Intensidad: {magnetStrength.toFixed(1)} T
                  </label>
                  <Slider
                    value={[magnetStrength]}
                    onValueChange={(m) => setMagnetStrength(m[0])}
                    min={0.1}
                    max={5}
                    step={0.1}
                    className="w-full"
                  />
                </div>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-3 block">Tipo de Campo:</label>
                  <Tabs value={fieldType} onValueChange={(v) => setFieldType(v as "dipole" | "solenoid")}>
                    <TabsList className="w-full">
                      <TabsTrigger value="dipole" className="flex-1">Imán</TabsTrigger>
                      <TabsTrigger value="solenoid" className="flex-1">Bobina</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>

                <div className="p-4 rounded-lg" style={{ background: "rgba(114, 9, 183, 0.05)", border: "1px solid rgba(114, 9, 183, 0.1)" }}>
                  <p className="text-xs font-medium text-white mb-2">Información:</p>
                  <ul className="text-xs space-y-1" style={{ color: "rgba(255,255,255,0.6)" }}>
                    <li>• Unidad: Tesla (T)</li>
                    <li>• Campo uniforme en bobina</li>
                    <li>• Líneas salen de N → S</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
