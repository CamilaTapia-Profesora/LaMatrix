/* ============================================================
   Óptica — Refracción y Reflexión Interactivas
   ============================================================ */
import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Eye } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { OpticsVisualizer } from "@/components/OpticsVisualizer";

export default function FisicaOptica() {
  const [angle, setAngle] = useState(30);
  const [opticsType, setOpticsType] = useState<"refraction" | "reflection">("refraction");
  const [refractiveIndex, setRefractiveIndex] = useState(1.33);

  return (
    <div className="min-h-screen" style={{ background: "#050914" }}>
      <NavBar />

      <section className="py-16">
        <div className="container">
          <Link href="/fisica">
            <span className="inline-flex items-center gap-1.5 text-sm mb-6 transition-colors hover:opacity-80"
              style={{ color: "rgba(0, 245, 212, 0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
              <ArrowLeft size={14} /> volver a física
            </span>
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(255, 159, 28, 0.1)", border: "1px solid rgba(255, 159, 28, 0.3)" }}>
              <Eye size={24} style={{ color: "#ff9f1c" }} />
            </div>
            <div>
              <p className="text-xs font-medium" style={{ color: "rgba(255, 159, 28, 0.5)", fontFamily: "'JetBrains Mono', monospace" }}>
                // óptica
              </p>
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Refracción y Reflexión
              </h1>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Visualizador */}
            <div className="lg:col-span-2">
              <div className="cyber-card rounded-xl p-6 mb-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Visualización de Rayos de Luz
                </h3>
                <OpticsVisualizer
                  angle={angle}
                  opticsType={opticsType}
                  refractiveIndex={refractiveIndex}
                />
              </div>

              <div className="cyber-card rounded-xl p-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Leyes Fundamentales
                </h3>
                <div className="space-y-3 text-sm" style={{ color: "rgba(255,255,255,0.6)" }}>
                  {opticsType === "refraction" ? (
                    <>
                      <p><strong>Ley de Snell:</strong> n₁·sin(θ₁) = n₂·sin(θ₂)</p>
                      <p><strong>Índice de Refracción:</strong> Relación entre velocidad de luz en vacío y en el medio.</p>
                      <p><strong>Agua:</strong> n ≈ 1.33 | <strong>Vidrio:</strong> n ≈ 1.5</p>
                    </>
                  ) : (
                    <>
                      <p><strong>Ley de Reflexión:</strong> θᵢ = θᵣ</p>
                      <p><strong>Ángulo de Incidencia:</strong> Igual al ángulo de reflexión.</p>
                      <p><strong>Normal:</strong> Línea perpendicular a la superficie.</p>
                    </>
                  )}</div>
              </div>
            </div>

            {/* Controles */}
            <div className="lg:col-span-1">
              <div className="cyber-card rounded-xl p-6 sticky top-20">
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Parámetros
                </h3>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Ángulo de Incidencia: {angle.toFixed(1)}°
                  </label>
                  <Slider
                    value={[angle]}
                    onValueChange={(a) => setAngle(a[0])}
                    min={0}
                    max={85}
                    step={1}
                    className="w-full"
                  />
                </div>

                {opticsType === "refraction" && (
                  <div className="mb-6">
                    <label className="text-sm font-medium text-white mb-2 block">
                      Índice de Refracción: {refractiveIndex.toFixed(2)}
                    </label>
                    <Slider
                      value={[refractiveIndex]}
                      onValueChange={(n) => setRefractiveIndex(n[0])}
                      min={1}
                      max={2.5}
                      step={0.01}
                      className="w-full"
                    />
                  </div>
                )}

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-3 block">Tipo de Fenómeno:</label>
                  <Tabs value={opticsType} onValueChange={(v) => setOpticsType(v as "refraction" | "reflection")}>
                    <TabsList className="w-full">
                      <TabsTrigger value="refraction" className="flex-1 text-xs">Refracción</TabsTrigger>
                      <TabsTrigger value="reflection" className="flex-1 text-xs">Reflexión</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>

                <div className="p-4 rounded-lg" style={{ background: "rgba(255, 159, 28, 0.05)", border: "1px solid rgba(255, 159, 28, 0.1)" }}>
                  <p className="text-xs font-medium text-white mb-2">Observa:</p>
                  <ul className="text-xs space-y-1" style={{ color: "rgba(255,255,255,0.6)" }}>
                    <li>• Cambio de dirección</li>
                    <li>• Dependencia del medio</li>
                    <li>• Ángulos críticos</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
