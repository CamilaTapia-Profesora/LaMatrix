/* ============================================================
   Movimiento y Fuerzas — Cinemática Interactiva
   ============================================================ */
import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Rocket } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { MovementVisualizerAdvanced } from "@/components/MovementVisualizerAdvanced";

export default function FisicaMovimiento() {
  const [velocity, setVelocity] = useState(20);
  const [acceleration, setAcceleration] = useState(2);
  const [isRunning, setIsRunning] = useState(false);

  return (
    <div className="min-h-screen" style={{ background: "#050914" }}>
      <NavBar />

      <section className="py-16">
        <div className="container">
          <Link href="/fisica">
            <span className="inline-flex items-center gap-1.5 text-sm mb-6 transition-colors hover:opacity-80"
              style={{ color: "rgba(0, 245, 212, 0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
              <ArrowLeft size={14} /> volver a física
            </span>
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(0, 245, 212, 0.1)", border: "1px solid rgba(0, 245, 212, 0.3)" }}>
              <Rocket size={24} style={{ color: "#00f5d4" }} />
            </div>
            <div>
              <p className="text-xs font-medium" style={{ color: "rgba(0, 245, 212, 0.5)", fontFamily: "'JetBrains Mono', monospace" }}>
                // movimiento y fuerzas
              </p>
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Cinemática Interactiva
              </h1>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Visualizador */}
            <div className="lg:col-span-2">
              <div className="cyber-card rounded-xl p-6 mb-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Visualización del Movimiento
                </h3>
                <MovementVisualizerAdvanced
                  initialVelocity={velocity}
                  acceleration={acceleration}
                  isRunning={isRunning}
                />
              </div>

              <div className="cyber-card rounded-xl p-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Ecuación de Movimiento
                </h3>
                <p className="text-sm mb-4" style={{ color: "rgba(255,255,255,0.7)", fontFamily: "'JetBrains Mono', monospace" }}>
                  x = x₀ + v₀·t + ½·a·t²
                </p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>
                  Donde: x es la posición, v₀ es la velocidad inicial, a es la aceleración y t es el tiempo.
                </p>
              </div>
            </div>

            {/* Controles */}
            <div className="lg:col-span-1">
              <div className="cyber-card rounded-xl p-6 sticky top-20">
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Parámetros
                </h3>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Velocidad Inicial: {velocity.toFixed(1)} m/s
                  </label>
                  <Slider
                    value={[velocity]}
                    onValueChange={(v) => setVelocity(v[0])}
                    min={-50}
                    max={50}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Aceleración: {acceleration.toFixed(1)} m/s²
                  </label>
                  <Slider
                    value={[acceleration]}
                    onValueChange={(a) => setAcceleration(a[0])}
                    min={-10}
                    max={10}
                    step={0.5}
                    className="w-full"
                  />
                </div>

                <button
                  onClick={() => setIsRunning(!isRunning)}
                  className="w-full py-3 rounded-lg font-semibold text-sm transition-all"
                  style={{
                    background: isRunning ? "rgba(247, 37, 133, 0.15)" : "rgba(0, 245, 212, 0.15)",
                    border: `1px solid ${isRunning ? "rgba(247, 37, 133, 0.4)" : "rgba(0, 245, 212, 0.4)"}`,
                    color: isRunning ? "#f72585" : "#00f5d4",
                    fontFamily: "'Space Grotesk', sans-serif",
                  }}
                >
                  {isRunning ? "Detener" : "Iniciar"}
                </button>

                <div className="mt-6 p-4 rounded-lg" style={{ background: "rgba(0, 245, 212, 0.05)", border: "1px solid rgba(0, 245, 212, 0.1)" }}>
                  <p className="text-xs font-medium text-white mb-2">Conceptos clave:</p>
                  <ul className="text-xs space-y-1" style={{ color: "rgba(255,255,255,0.6)" }}>
                    <li>• Velocidad: cambio de posición</li>
                    <li>• Aceleración: cambio de velocidad</li>
                    <li>• Movimiento uniformemente acelerado</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
