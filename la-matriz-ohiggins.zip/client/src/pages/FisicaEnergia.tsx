/* ============================================================
   Energía y Trabajo — Transformación de Energía
   ============================================================ */
import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Flame } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { EnergyVisualizer } from "@/components/EnergyVisualizer";

export default function FisicaEnergia() {
  const [height, setHeight] = useState(50);
  const [mass, setMass] = useState(1);
  const [isDropping, setIsDropping] = useState(false);

  return (
    <div className="min-h-screen" style={{ background: "#050914" }}>
      <NavBar />

      <section className="py-16">
        <div className="container">
          <Link href="/fisica">
            <span className="inline-flex items-center gap-1.5 text-sm mb-6 transition-colors hover:opacity-80"
              style={{ color: "rgba(0, 245, 212, 0.6)", fontFamily: "'JetBrains Mono', monospace" }}>
              <ArrowLeft size={14} /> volver a física
            </span>
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(255, 214, 10, 0.1)", border: "1px solid rgba(255, 214, 10, 0.3)" }}>
              <Flame size={24} style={{ color: "#ffd60a" }} />
            </div>
            <div>
              <p className="text-xs font-medium" style={{ color: "rgba(255, 214, 10, 0.5)", fontFamily: "'JetBrains Mono', monospace" }}>
                // energía y trabajo
              </p>
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Transformación de Energía
              </h1>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Visualizador */}
            <div className="lg:col-span-2">
              <div className="cyber-card rounded-xl p-6 mb-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Caída Libre: Conversión Ep ↔ Ek
                </h3>
                <EnergyVisualizer
                  height={height}
                  mass={mass}
                  isDropping={isDropping}
                />
              </div>

              <div className="cyber-card rounded-xl p-6">
                <h3 className="text-lg font-bold text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Fórmulas Fundamentales
                </h3>
                <div className="space-y-3 text-sm" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  <p style={{ color: "rgba(0, 245, 212, 0.8)" }}>Ep = m·g·h</p>
                  <p style={{ color: "rgba(247, 37, 133, 0.8)" }}>Ek = ½·m·v²</p>
                  <p style={{ color: "rgba(255, 214, 10, 0.8)" }}>Et = Ep + Ek</p>
                </div>
              </div>
            </div>

            {/* Controles */}
            <div className="lg:col-span-1">
              <div className="cyber-card rounded-xl p-6 sticky top-20">
                <h3 className="text-lg font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Parámetros
                </h3>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Altura: {height.toFixed(1)} m
                  </label>
                  <Slider
                    value={[height]}
                    onValueChange={(h) => setHeight(h[0])}
                    min={0}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div className="mb-6">
                  <label className="text-sm font-medium text-white mb-2 block">
                    Masa: {mass.toFixed(1)} kg
                  </label>
                  <Slider
                    value={[mass]}
                    onValueChange={(m) => setMass(m[0])}
                    min={0.1}
                    max={10}
                    step={0.1}
                    className="w-full"
                  />
                </div>

                <button
                  onClick={() => setIsDropping(!isDropping)}
                  className="w-full py-3 rounded-lg font-semibold text-sm transition-all"
                  style={{
                    background: isDropping ? "rgba(247, 37, 133, 0.15)" : "rgba(255, 214, 10, 0.15)",
                    border: `1px solid ${isDropping ? "rgba(247, 37, 133, 0.4)" : "rgba(255, 214, 10, 0.4)"}`,
                    color: isDropping ? "#f72585" : "#ffd60a",
                    fontFamily: "'Space Grotesk', sans-serif",
                  }}
                >
                  {isDropping ? "Detener" : "Soltar"}
                </button>

                <div className="mt-6 p-4 rounded-lg" style={{ background: "rgba(255, 214, 10, 0.05)", border: "1px solid rgba(255, 214, 10, 0.1)" }}>
                  <p className="text-xs font-medium text-white mb-2">Observa:</p>
                  <ul className="text-xs space-y-1" style={{ color: "rgba(255,255,255,0.6)" }}>
                    <li>• Ep disminuye → Ek aumenta</li>
                    <li>• Energía total conservada</li>
                    <li>• Aceleración: 9.8 m/s²</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
